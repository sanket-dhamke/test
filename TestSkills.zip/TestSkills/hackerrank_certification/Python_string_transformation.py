#!/bin/python3

import math
import os

def transformSentence(sentence):
    list1 = sentence.split()
    list2 = []
    op_sentence = ""

    for i in list1:
        op_sentence += i[0]
        for j in range(0, len(i) - 1):
            if (i[j + 1].lower() > i[j].lower()):
                op_sentence = op_sentence + i[j + 1].upper()
            elif i[j + 1].lower() < i[j].lower():
                op_sentence = op_sentence + i[j + 1].lower()
            else:
                op_sentence = op_sentence + i[j + 1]

        list2.append(op_sentence)
        op_sentence = ""

    result = ""

    for i in list2:
        result = result + " " + i
    return (result.strip())

    # Write your code here


if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    sentence = input()

    result = transformSentence(sentence)

    fptr.write(result + '\n')

    fptr.close()