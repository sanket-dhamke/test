def fizzBuzz(n):
    # Write your code here
    for i in range(0, n + 1):
        if i % 5 != 0 and i % 3 != 0:
            print(i)
        elif i % 3 == 0 and i % 5 != 0:
            print("Fizz")
        elif i % 5 == 0 and i % 3 != 0:
            print("Buzz")
        else:
            print("FizzBuzz")


if __name__ == '__main__':
    print(3%3 == 0)
    n = int(input("Enter no:").strip())

    fizzBuzz(n)
