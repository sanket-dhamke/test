#!/bin/python3

import math
import os
import random
import re
import sys


class VendingMachine:
    # Implement the VendingMachine here
    def __init__(self, num_items, item_coins):  # 10 2 20 oins
        self.num_items = num_items
        self.item_coins = item_coins

    def buy(self, req_items, num_coins):  # 1, 5 = 5 - 1*2 =3 coins left and 10-1 = 9 items left

        total_items_left = num_items - req_items
        if total_items_left > 0:
            pass
        else:
            return "Not enough items in the console"

        total_money_left = item_coins - (num_coins - (req_items * 2))
        if total_money_left > 0:
            pass
        else:
            return "Not enough coins"

        return total_items_left, total_money_left


if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    num_items, item_coins = map(int, input().split())
    machine = VendingMachine(num_items, item_coins)

    n = int(input())
    for _ in range(n):
        num_items, num_coins = map(int, input().split())
        try:
            change = machine.buy(num_items, num_coins)
            fptr.write(str(change) + "\n")
        except ValueError as e:
            fptr.write(str(e) + "\n")

    fptr.close()
