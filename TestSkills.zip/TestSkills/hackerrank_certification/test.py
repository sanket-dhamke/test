"""
4
sank
samir
sam
click
o/p: this is method
"""

"""
def result():
    L = []
    n = int(input("Enter input"))
    for _ in range(n):
        text1 = input().strip().split()
        for i in text1:
            if i.lower() == 'click':
                print(i+'is'+'method')
            else:
                L.append(i)
    return L


v = result()
print(v)
"""


def revWord(s1):
    l1 = []
    tp = ""
    for i in range(len(s1)-1, 0, -1):
        if s1[i].isupper():
            for j in range(i + 1, len(s1)):
                if s1[j].islower():
                    tp = tp + s1[i:j]
                else:
                    d = 1
        else:
            d = 0
    l1.append(tp)
    return l1


print(revWord("HiSanket"))

"""s = "CodeSanketDhamke"
l = list(s)
print(l)
s.isupper()
L1 = []
rev = ""
for i in range(0, len(l)):
    if l[i].isupper():
        for j in range(i+1, len(l)):
            if l[j].isupper():
                for k in range(i,j):
                    rev = rev + l[k]
"""
