
# longest palindrome in string

def palindrome(str1):
    longest = ''
    for i in range(len(str1)):
        for j in range(len(str1), i , -1):
            if len(longest) >= j - i:
                break
            elif str1[i:j] == str1[i:j][::-1]:
                longest = str1[i:j]
                break
    return longest


result = palindrome("asdsadfgh")
print(result)
