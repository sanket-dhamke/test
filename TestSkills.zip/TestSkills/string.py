

lead1 = "aanket Rajendra Dhamkaaaa"
print(lead1.join("join"))
print(lead1[::-1])
print('i have',len(lead1), 'mango')
print('output is {} {} '.format("", lead1.count("a")))

# split method to convert string into list
print(lead1.split(" "))
tup = lead1.split(" ")                 # StringToLIST
print(tup[::-1])                       # reverse
len(tup)                               # length

# convert list to string
var = " ".join(tup)                    # ListToSTRING

rem = lead1.strip("a")
print(rem)

print(tup.count("Sanket"))


#list to tuple
L1 = ('abcd', 'zxcv', 'fghj')
T1 = list(L1)
print(T1)


T1.sort()
print(T1)
print(T1[2])

#dict
D1 = {}
D1['one'] = 1
print(D1)

print("Take Take Take", D1)

for i in D1.keys():
    if i is 'one':
        print("Value matching")
        v = D1['one']
        del D1['one']
        D1['1'] = v

        print(D1)



try:
    f = open("C:\\Tools\\test.txt")
    str1 = f.readlines()
    str2 = [i.strip() for i in str1]
    #flist = str1.split(" ")
    print(str2)
    print(str2.count('n'))
except:
    print("Error")
finally:
    print("close the testcase")


input1 = "aaabbccccd"
il = list(input1)
ll = list()
print(il)
for i in il:
    if il.count(i) > 1:
        ll.append(i + str(il.count(i)))
print(ll)
print(set(ll))
fo = "".join(set(ll))
print(fo)

#find longest palindrome string
sd = "avbcbvdtzzoaaaaaaaop"
longest = ""
print(sd[::-1])
final = []

for i in range(0, len(sd)):
    for j in range(len(sd), 0, -1):
        k = j - i
        if k > 1:
            rev = sd[i:j]
            print(rev)
            if rev == rev[::-1]:
                final.append(rev)
            else:
                pass

print(final)
cout = 0
z = []

for i in final:
    if len(i) > cout:
        cout = len(i)
        if len(z) == 0:
            z.append(i)
        else:
            z.clear()
            z.append(i)
print(z)


# ZIP function

z1 = [2 , 4 , 6, 8]
z2 = [1, 3, 5, 2]
z = [i for i in z1 if i in z2]
y = [i for i in set(z1).union(set(z2)) if i not in z]
#y.remove(y.index(z))
print('-----------------------------------------')
print(z)
print(y)
#z = [(i) for i in z1 if i not in z2 for i in z2 if i not in z1]
print(z)
z3 = zip(z1, z2)
x1 = [[x,y] for x,y in z3]
print('x value')
print(x1)

z4 = []
for i in x1:
    print(i[0])
    z4.append(i[0])
    z4.append(i[1])
print(z4)

    #for j in range(len(sd), 0):




