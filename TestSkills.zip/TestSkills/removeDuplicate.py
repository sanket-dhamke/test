
L1 = "asdfgavcadfam"
L2= "".join(dict.fromkeys(L1))
print(L2)

L1 = [1, 2, 4, 2, 3, 2, 9]
L = str(L1)
#L = ''.join(L1)
print(L)

result = "".join(str(L))
print(result)
