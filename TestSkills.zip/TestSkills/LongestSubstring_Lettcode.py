"""
s= abcbbbjk
op: 3
abc

s=bbbb
o/p= 1
b
"""


def count_substring(str1):
    op1 = []
    for i in range(len(str1)):   # 0 
        for j in range(len(str1), 0, -1):    #4          # [bbbb]
            while len(op1[0]) == len(set(op1[0])):
                if len(op1[0]) < len(set(op1[0])):
                    op1.append(str1[i:j])
            else:
                pass
    print(len(set(op1)))


count_substring("bbbb")


