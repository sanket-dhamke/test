
L = []


def twoSum(nums, target):
    for i in range(len(nums)):
        if nums[i] + nums[i + 1] == target:
            L.append(i)
            L.append(i + 1)
            break
        else:
            print("No output")
    return L

print(twoSum([2, 7, 2, 5], 9))
