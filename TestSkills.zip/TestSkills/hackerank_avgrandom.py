# 2
# sam 10 12 13
#ram 10 10 10
#ram
#OP 10

if __name__ == '__main__':
    n = int(input())
    student_marks = {}
    for _ in range(n):
        name, *line = input().split()
        scores = list(map(float, line))
        #print(scores, '****')
        student_marks[name] = scores
    query_name = input()

    for key, value in student_marks.items():
        if query_name == key:
            sum = 0
            count = 0
            for i in value:
                sum += i
                count += 1
            average = sum / count
            #print("{:.2f}".format(average))
            print(average)
